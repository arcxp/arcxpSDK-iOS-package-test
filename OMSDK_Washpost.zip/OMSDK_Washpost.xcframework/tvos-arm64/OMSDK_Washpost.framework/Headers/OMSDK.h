//
//  OMSDK.h
//  OMSDK
//
//  Created by Nathanael Hardy on 10/16/20.
//

#import <Foundation/Foundation.h>

//! Project version number for OMSDK.
FOUNDATION_EXPORT double OMSDKVersionNumber;

//! Project version string for OMSDK.
FOUNDATION_EXPORT const unsigned char OMSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OMSDK/PublicHeader.h>

#import <OMSDK/OMIDImports.h>
